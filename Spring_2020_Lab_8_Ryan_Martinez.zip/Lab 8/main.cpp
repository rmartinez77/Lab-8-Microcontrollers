#include <Arduino.h>
// import {Name_of_the_Library}

#define buttonPin = 2;
#define LedPin = 13; // const int constant integer

in buttonState = 0; // int integer datatype

void setup() {
  // put your setup code here, to run once:
  
  // Lab 8 - Blink Led
  pinmode(LedPin, OUTPUT)

  // Lab 8 - Button
  pinMode(buttonPin, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  buttonState = digitalRead(buttonPin);

  // check
  digitalWrite(LED_BUILTIN, HIGH);
  delay(1000);
  digitalWrite(LED_BUILTIN, LOW);
  delay(1000);
  // 100 ms (HIGH) + 100 ms (LOW) = 200 ms = 0.2s => 1/2.0
}